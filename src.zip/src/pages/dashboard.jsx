const Dashboard = () => {
    return (
        <div>
            Main Content
        </div>
    );
}

export default Dashboard