import { Link} from 'react-router-dom'

const NotFound = () => {
    return (
        <div className='flex flex-col justify-center items-center'>
            <img src="images/404.jpg" width={500}/>
            <span className='text-xl text-slate-500 select-none'>
                looks like you got lost go back to <Link to="/" className='underline underline-offset-8 '>Homepage</Link>
            </span>
        </div>
    );
}
export default NotFound