import { useState } from 'react';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';

import Appsetting from './components/appsetting';
import Appsidebar from './components/Appsidebar';
import MenuClose from './components/Topbar';
import Sidebar from './components/Sidebar';

import Dashboard from './pages/dashboard';
import NotFound from './pages/NotFound';

function App() {
  const [showsetting, setShowsetting] = useState(false);
  const [showsidebar, setShowsidebar] = useState(true);
  
  return (
    <div className="App"> 
        <Router>
          <div className='flex'>
            {showsidebar && <Sidebar/>}
            <div className="flex-1">
              <MenuClose setShowsidebar={setShowsidebar} showsidebar={showsidebar}/>
              <Routes>
                <Route exact path="/" element={<Dashboard/>}/>
                <Route path='*' element={<NotFound/>}/>
              </Routes> 
            </div>
            <Appsetting setShowsetting={setShowsetting}/>
            {showsetting && <Appsidebar setShowsetting={setShowsetting}/>}
          </div>
          
        </Router>       
    </div>
  );
}



export default App;
