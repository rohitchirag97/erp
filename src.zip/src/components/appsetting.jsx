import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faGear } from '@fortawesome/free-solid-svg-icons'

const Appsetting = ({setShowsetting}) => {
  return (
    <div className='fixed bottom-3 right-6 bg-blue-500 px-3 py-2 rounded-full cursor-pointer' onClick={()=> setShowsetting(true)}>
        <FontAwesomeIcon icon={faGear} className="text-white"/>
    </div>
  )
}

export default Appsetting