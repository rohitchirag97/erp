import React from 'react'

const Sidebar = () => {
  return (
    <div className="flex-none w-64 h-screen bg-slate-100 border-r border-r-slate-200 drop-shadow">
        Sidebar
    </div>
  )
}

export default Sidebar