import React from 'react'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowRight } from '@fortawesome/free-solid-svg-icons'

const Appsidebar = ({setShowsetting}) => {
  return (
    <div className='w-64 z-50 fixed right-0 top-0 border-l border-l-red-400 h-screen bg-white'>
      <div onClick={()=> setShowsetting(false)}>
        <FontAwesomeIcon icon={faArrowRight} />
      </div>
      Appsidebar
    </div>
  )
}

export default Appsidebar