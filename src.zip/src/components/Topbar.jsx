import React from 'react'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowLeft, faBars, faUser } from '@fortawesome/free-solid-svg-icons'

const TopBar = ({setShowsidebar, showsidebar}) => {
  return (
    <div className='flex justify-between items-center border-b border-b-slate-200 pl-3 bg-lime-600'>
      <div onClick={()=>setShowsidebar(!showsidebar)} className="flex items-center py-2 gap-5">
        <FontAwesomeIcon icon={showsidebar ? faArrowLeft : faBars} className="border border-white px-2 py-2 text-white rounded-md"/>
        <FontAwesomeIcon icon={faUser} className="text-2xl text-white"/>
        <span className='text-2xl text-white'>Asha Corporation</span>
      </div>
      <div></div>
    </div>
  )
}

export default TopBar